<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

//include Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Example extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        //load user model
        $this->load->model('offer');
        $this->load->model('user');
        $this->load->model('order');
        $this->load->model('product');
        $this->load->model('product_translation');
    }
    
    public function offer_get($id = 0) {
        //returns all rows if the id parameter doesn't exist,
        //otherwise single row will be returned
        $offers = $this->offer->getRows($id);
        
        //check if the user data exists
        if(!empty($offers)){
            //set the response and exit
            $this->response($offers, REST_Controller::HTTP_OK);
        }else{
            //set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No user were found.'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function validoffer_get($id = 0) {
        //returns all rows if the id parameter doesn't exist,
        //otherwise single row will be returned
        $offers = $this->offer->getRowsValid();
        
        //check if the user data exists
        if(!empty($offers)){
            //set the response and exit
            $this->response($offers, REST_Controller::HTTP_OK);
        }else{
            //set the response and exit
            $this->response([
                'status' => FALSE,
                'message' => 'No user were found.'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    
    public function offer_post() {
        $orderData = array();
        $orderData['offer_id'] = $this->post('id');
        $orderData['amount'] = $this->post('offer_price');
        $orderData['token'] = sprintf("%06d", mt_rand(1, 999999));
        $orderData['order_date'] = date("Y-m-d H:i:s");
        //get the product from product id
        $product_id = $this->post('product_id');
        if(!empty($product_id )){
            $productData = $this->product_translation->getRows($product_id);
            $orderData['product_name'] = $productData['name'];
            $orderData['product_id'] = $this->post('product_id');
        }
        
        $userData = array();
        $userData['phone'] = $this->post('phone');
        if(!empty($this->post('ivr_option')) && $this->post('ivr_option')==1){
            //insert user data
            //Check if a user exists with given phone number
            $user = $this->user->getRows($userData['phone']);
            if(empty($user)){
                $user = $this->user->insert($userData);   
            }
            
            $orderData['user_id'] = $user;
            //check if the user data inserted
            if($insert){
                //set the response and exit
                $this->response([
                    'status' => TRUE,
                    'message' => 'User has been added successfully.'
                ], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
                $this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            //set the response and exit
            $this->response("Provide complete user information to create.", REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}

?>