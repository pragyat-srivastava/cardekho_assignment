<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class ProductLike extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    /*
     * Fetch user data
     */
    function getRows($productId = ""){
        if(!empty($productId)){
            $query = $this->db->get_where('product_likes', array('id' => $productId));
            return $query->row_array();
        }else{
            $query = $this->db->get('product_likes');
            return $query->result_array();
        }
    }
    
    /*
     * Insert user data
     */
    public function insert($data = array()) {
        if(!array_key_exists('created', $data)){
            $data['created'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists('modified', $data)){
            $data['modified'] = date("Y-m-d H:i:s");
        }
        $insert = $this->db->insert('product_likes', $data);
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }
}
?>